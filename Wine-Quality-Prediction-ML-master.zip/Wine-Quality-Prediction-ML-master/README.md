# Wine-Quality-Prediction-ML
Used Multiple Linear Regression which will predict the quality of wine using 11 features.
The dataset was taken from the UCI Machine Learning Repository.There are 4898 samples of white wine in the dataset.

