from django.apps import AppConfig


class CultivoMainConfig(AppConfig):
    name = 'cultivo_main'
