from django.apps import AppConfig


class StateAuthConfig(AppConfig):
    name = 'state_auth'
